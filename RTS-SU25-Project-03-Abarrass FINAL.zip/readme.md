# This is a Markdown Level 1 header

Go ahead and use this readme to write your application report questions

## Level 2 Heading

Want to learn more about markdown?
[Website Title](https://www.markdownguide.org/cheat-sheet/)

## Code example

```python
import foobar

# returns 'words'
foobar.pluralize('word')

# returns 'geese'
foobar.pluralize('goose')

# returns 'phenomenon'
foobar.singularize('phenomena')
```



